function szamolas() {
    let elso = parseInt(document.getElementById('elso').value);
    let masodik = parseInt(document.getElementById('masodik').value);
    let muvelet = document.getElementById('muvelet').value;

    let eredmeny;
    let e = document.getElementById('eredmeny');
    console.log(elso);
    console.log(masodik);
    console.log(muvelet);

    switch (muvelet) {
        case 'osszeadas':
            eredmeny = elso + masodik;
            e.innerHTML = 'Eredmeny: ' + eredmeny;
            break;
        case 'kivonas':
            eredmeny = elso - masodik;
            e.innerHTML = 'Eredmeny: ' + eredmeny;
            break;
        case 'szorzas':
            eredmeny = elso * masodik;
            e.innerHTML = 'Eredmeny: ' + eredmeny;
            break;
        case 'osztas':
            eredmeny = elso / masodik;
            e.innerHTML = 'Eredmeny: ' + eredmeny;
            break;
        default:
            e.innerHTML = 'Hiba';
            break;
    }
}
