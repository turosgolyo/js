function szamolas() {
    let osszeg = document.getElementById("osszeg").value;
    let penznem = document.getElementById("penznem").value;
    let atvaltott;
    
    switch (penznem) {
        case "euro":
            atvaltott = osszeg / 380;
            document.getElementById("atvaltott").innerHTML= osszeg + " Ft - " + atvaltott.toFixed(2) + " €";
            break;
        case "dollar":
            atvaltott = osszeg / 350;
            document.getElementById("atvaltott").innerHTML= osszeg + " Ft - " + atvaltott.toFixed(2) + " $";
            break;
        default: 
            break;
    }
}